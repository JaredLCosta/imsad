var router = require('express').Router();
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var sequelize = require('../db.js');
var User = sequelize.import('../models/user.js');

router.post('/', function(req, res){
    User.findOne({where:{username: req.body.user.username}}).then(
        function(user){ console.log(user)
            if(user){
                bcrypt.compare(req.body.user.passwordhash, user.passwordhash, function(err, matches){
                    if(matches){
                        var token = jwt.sign({id: user.id}, process.env.JWT_SECRET, {expiresIn:60*60*24});
                        res.json({
                            user: user,
                            message: "logged in",
                            sessionToken: token
                        });
                    } else {
                        res.status(500).send({error:"wrong password"})
                    }
                });
            } else {
                res.status(500).send({error:"User dosent exist"})
            }
        },
        function(err){
            res.json(err);
        }
    )
})

module.exports = router;